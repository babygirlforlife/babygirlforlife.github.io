const express = require('express');
const router = express.Router();
const tripsController = require('../controllers/trips');
const authController = require('../controllers/authentication');
const auth = require('../middleware/auth');

// Auth routes (public)
router.post('/register', authController.register);
router.post('/login', authController.login);

// Trip routes - GET is public, write ops require auth
router.get('/trips', tripsController.tripsList);
router.get('/trips/:tripCode', tripsController.tripsFind);
router.post('/trips', auth, tripsController.tripsAddTripV2);
router.put('/trips/:tripCode', auth, tripsController.tripsUpdateTrip);
router.delete('/trips/:tripCode', auth, tripsController.tripsDeleteTrip);

module.exports = router;
