const Trip = require('../models/travlr');

const tripsList = async (req, res) => {
    Trip
        .find({})
        .exec()
        .then(trips => {
            if (!trips) {
                return res.status(404).json({ message: 'No trips found' });
            }
            return res.status(200).json(trips);
        })
        .catch(err => res.status(500).send(err));
};

const tripsFind = async (req, res) => {
    Trip
        .find({ code: req.params.tripCode })
        .exec()
        .then(trips => {
            if (!trips) {
                return res.status(404).json({ message: 'Trip not found' });
            }
            return res.status(200).json(trips);
        })
        .catch(err => res.status(500).send(err));
};

module.exports = {
    tripsList,
    tripsFind
};

const tripsAddTrip = async (req, res) => {
  try {
    const Trip = require('../models/travlr');
    const trip = await Trip.create(req.body);
    res.status(201).json(trip);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

const tripsUpdateTrip = async (req, res) => {
  try {
    const Trip = require('../models/travlr');
    const trip = await Trip.findOneAndUpdate({ code: req.params.tripCode }, req.body, { returnDocument: 'after' });
    res.status(200).json(trip);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

const tripsDeleteTrip = async (req, res) => {
  try {
    const Trip = require('../models/travlr');
    await Trip.findOneAndDelete({ code: req.params.tripCode });
    res.status(204).json({});
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

module.exports.tripsAddTrip = tripsAddTrip;
module.exports.tripsUpdateTrip = tripsUpdateTrip;
module.exports.tripsDeleteTrip = tripsDeleteTrip;


const tripsAddTripV2 = async (req, res) => {
  try {
    const trip = await Trip.create({
      code: req.body.code,
      name: req.body.name,
      length: req.body.length,
      start: req.body.start || new Date(),
      resort: req.body.resort,
      perPerson: req.body.perPerson,
      image: req.body.image || 'default.jpg',
      description: req.body.description
    });
    res.status(201).json(trip);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
module.exports.tripsAddTripV2 = tripsAddTripV2;

const tripsUpdateTripV2 = (req, res) => {
  const Trip = require('../models/travlr');
  Trip.findOneAndUpdate(
    { code: req.params.tripCode },
    req.body,
    { returnDocument: 'after' }
  ).then(trip => {
    if (!trip) return res.status(404).json({ message: 'Not found' });
    res.status(200).json(trip);
  }).catch(err => res.status(500).json({ error: err.message }));
};
module.exports.tripsUpdateTripV2 = tripsUpdateTripV2;
