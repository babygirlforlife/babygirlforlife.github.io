import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TripService } from '../trip.service';
import { Trip } from '../trip';

@Component({
  selector: 'app-add-trip',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './add-trip.html',
  styleUrl: './add-trip.css'
})
export class AddTripComponent {
  message = signal<string>('');
  trip: Trip = {
    _id: '',
    code: '',
    name: '',
    length: '',
    start: new Date(),
    resort: '',
    perPerson: 0,
    image: '',
    description: ''
  };

  constructor(private tripService: TripService) {}

  onSubmit(): void {
    this.tripService.addTrip(this.trip).subscribe({
      next: () => { this.message.set('Trip added successfully!'); },
      error: () => { this.message.set('Error adding trip.'); }
    });
  }
}
