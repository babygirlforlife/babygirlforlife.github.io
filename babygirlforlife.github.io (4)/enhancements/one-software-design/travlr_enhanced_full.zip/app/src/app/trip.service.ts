import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Trip } from './trip';
import { environment } from '../environments/environment';

// Enhancement note (CS 499, Software Design and Engineering):
//  - Removed the hard coded API URL; it now comes from the environment config.
//  - Documented the service and kept the data-access logic isolated here so the
//    components stay focused on presentation (separation of concerns).
@Injectable({
  providedIn: 'root'
})
export class TripService {
  private apiUrl = `${environment.apiBaseUrl}/trips`;

  constructor(private http: HttpClient) {}

  getTrips(): Observable<Trip[]> {
    return this.http.get<Trip[]>(this.apiUrl);
  }

  getTrip(tripCode: string): Observable<Trip> {
    return this.http.get<Trip>(`${this.apiUrl}/${tripCode}`);
  }

  addTrip(trip: Trip): Observable<Trip> {
    return this.http.post<Trip>(this.apiUrl, trip);
  }

  updateTrip(trip: Trip): Observable<Trip> {
    return this.http.put<Trip>(`${this.apiUrl}/${trip.code}`, {
      name: trip.name,
      length: trip.length,
      resort: trip.resort,
      perPerson: trip.perPerson,
      image: trip.image,
      description: trip.description
    });
  }

  deleteTrip(tripCode: string): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${tripCode}`);
  }
}
