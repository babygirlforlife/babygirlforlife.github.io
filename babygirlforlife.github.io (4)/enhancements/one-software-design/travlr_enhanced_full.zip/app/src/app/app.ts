import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TripListingComponent } from './trip-listing/trip-listing';
import { AddTripComponent } from './add-trip/add-trip';
import { EditTripComponent } from './edit-trip/edit-trip';
import { LoginComponent } from './login/login';
import { AuthService } from './auth.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, TripListingComponent, AddTripComponent, EditTripComponent, LoginComponent],
  template: `
    <nav class="navbar navbar-dark bg-dark mb-4">
      <div class="container">
        <span class="navbar-brand">Travlr Admin</span>
        <div>
          @if (authService.isLoggedIn()) {
            <button class="btn btn-outline-light me-2" (click)="view.set('list')">Trip List</button>
            <button class="btn btn-success me-2" (click)="view.set('add')">Add Trip</button>
            <button class="btn btn-warning me-2" (click)="view.set('edit')">Edit Trip</button>
            <button class="btn btn-outline-danger" (click)="logout()">Logout</button>
          } @else {
            <button class="btn btn-outline-light" (click)="view.set('login')">Login</button>
          }
        </div>
      </div>
    </nav>
    @if (!authService.isLoggedIn()) {
      <app-login (loginSuccess)="onLoginSuccess()"></app-login>
    } @else {
      @if (view() === 'list') {
        <app-trip-listing></app-trip-listing>
      }
      @if (view() === 'add') {
        <app-add-trip></app-add-trip>
      }
      @if (view() === 'edit') {
        <app-edit-trip></app-edit-trip>
      }
    }
  `
})
export class AppComponent {
  view = signal<string>('list');

  constructor(public authService: AuthService) {}

  onLoginSuccess(): void {
    this.view.set('list');
  }

  logout(): void {
    this.authService.logout();
    this.view.set('login');
  }
}
