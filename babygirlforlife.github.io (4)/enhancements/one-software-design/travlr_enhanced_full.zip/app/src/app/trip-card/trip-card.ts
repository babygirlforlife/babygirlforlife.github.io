import { Component, Input } from '@angular/core';
import { Trip } from '../trip';

@Component({
  selector: 'app-trip-card',
  standalone: true,
  templateUrl: './trip-card.html',
  styleUrl: './trip-card.css'
})
export class TripCardComponent {
  @Input() trip!: Trip;
}
