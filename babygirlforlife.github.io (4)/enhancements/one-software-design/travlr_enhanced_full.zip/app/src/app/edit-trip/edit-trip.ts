import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TripService } from '../trip.service';
import { Trip } from '../trip';

@Component({
  selector: 'app-edit-trip',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './edit-trip.html',
  styleUrl: './edit-trip.css'
})
export class EditTripComponent {
  message = signal<string>('');
  trip: Trip = {
    _id: '',
    code: 'ECUDOR24',
    name: 'Ecuador Amazon Adventure',
    length: '5 nights / 6 days',
    start: new Date(),
    resort: 'Napo Wildlife Center',
    perPerson: 2499,
    image: 'default.jpg',
    description: 'Explore the breathtaking Amazon rainforest in Ecuador. Canoe through pristine waterways, spot exotic wildlife, and experience indigenous culture in one of the most biodiverse places on Earth.'
  };

  constructor(private tripService: TripService) {}

  onSubmit(): void {
    this.tripService.updateTrip(this.trip).subscribe({
      next: () => { this.message.set('Trip updated successfully!'); },
      error: (err) => { this.message.set('Error: ' + err.message); }
    });
  }
}
