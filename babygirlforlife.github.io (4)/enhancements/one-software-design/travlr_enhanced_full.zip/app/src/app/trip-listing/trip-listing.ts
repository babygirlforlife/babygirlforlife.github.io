import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TripCardComponent } from '../trip-card/trip-card';
import { TripService } from '../trip.service';
import { Trip } from '../trip';

@Component({
  selector: 'app-trip-listing',
  standalone: true,
  imports: [CommonModule, TripCardComponent],
  templateUrl: './trip-listing.html',
  styleUrl: './trip-listing.css'
})
export class TripListingComponent implements OnInit {
  trips = signal<Trip[]>([]);
  message = signal<string>('');

  constructor(private tripService: TripService) {}

  ngOnInit(): void {
    this.tripService.getTrips().subscribe({
      next: (data) => { this.trips.set(data); },
      error: (err) => { this.message.set('Error loading trips'); }
    });
  }
}
