// src/environments/environment.ts
//
// Enhancement note (CS 499): the API base URL was hard coded as a string
// inside TripService. Centralizing it here removes the magic string from the
// service and gives a single place to change the endpoint per environment.
export const environment = {
  production: false,
  apiBaseUrl: 'http://localhost:3000/api'
};
