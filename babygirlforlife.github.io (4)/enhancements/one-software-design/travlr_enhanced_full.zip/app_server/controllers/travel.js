const tripsEndpoint = 'http://localhost:3000/api/trips';
const options = {
    method: 'GET',
    headers: {
        'Accept': 'application/json'
    }
};

const travel = async (req, res) => {
    await fetch(tripsEndpoint, options)
        .then(res => res.json())
        .then(json => {
            let trips = json;
            if (!trips) {
                return res.status(404).json({ message: 'No trips found' });
            }
            if (!Array.isArray(trips)) {
                return res.status(404).json({ message: 'Data is not an array' });
            }
            if (trips.length === 0) {
                return res.status(404).json({ message: 'No trips in database' });
            }
            res.render('travel', { trips });
        })
        .catch(err => res.status(500).send(err.message));
};

module.exports = {
    list: travel
};