// app.js
//
// Enhancement note (CS 499, Software Design and Engineering):
// dotenv is loaded first so configuration (including the JWT secret) is
// available everywhere. The API now has a dedicated JSON 404 handler and a
// centralized error handler, replacing the single HTML error page that
// previously caught everything. This keeps API responses consistent and
// prevents raw error details from leaking to clients.

require('dotenv').config();

var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var hbs = require('hbs');
require('./app_api/models/db');

var indexRouter = require('./app_server/routes/index');
var usersRouter = require('./app_server/routes/users');
var travelRouter = require('./app_server/routes/travel');
var apiRouter = require('./app_api/routes/index');
var { notFound, errorHandler } = require('./app_api/middleware/errorHandler');

var app = express();
var cors = require('cors');
app.use(cors());

// view engine setup
app.set('views', path.join(__dirname, 'app_server', 'views'));
app.set('view engine', 'hbs');
hbs.registerPartials(path.join(__dirname, 'app_server', 'views', 'partials'));

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter);
app.use('/users', usersRouter);
app.use('/travel', travelRouter);
app.use('/api', apiRouter);

// API 404: any unmatched /api route returns clean JSON
app.use('/api', notFound);

// Centralized API error handler: consistent JSON, no leaked internals
app.use('/api', errorHandler);

// catch 404 for the server-rendered site and forward to the HTML error handler
app.use(function (req, res, next) {
  next(createError(404));
});

// server-rendered error handler
app.use(function (err, req, res, next) {
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
